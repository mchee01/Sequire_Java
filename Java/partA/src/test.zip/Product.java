package test;

public abstract class Product {
    protected int price;
    protected String prdName;
    public abstract String sell(Object a);
    
}